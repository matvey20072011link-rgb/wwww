# Neat — Fabric 1.21.4

Client-side health bars for Minecraft Fabric 1.21.4.

## What was changed

- Target Minecraft **1.21.4**.
- Updated Fabric Loom/API/Loader and Cloth Config dependencies for the 1.21.4 toolchain.
- Removed the NeoForge module from the build because this repository target is Fabric 1.21.4.
- Health text reads the entity's **currently client-synchronized `LivingEntity` health and max-health** values instead of default entity attributes.
- Added guards for zero/invalid max health, invalid config decimal formats, and invalid floating-point values.
- Exact HP display is enabled by default with `Float.toString`, so the mod does not intentionally round the server-synchronized float.
- Percentage and bar width are clamped safely to 0–100% / 0–1.
- Added a GitHub Actions workflow in `.github/workflows/build.yml`.

## Important server limitation

A client-only mod cannot read a value that a server never sends to the client. On vanilla/Fabric-compatible servers using normal Minecraft entity synchronization, this implementation displays the health/max-health values currently known by the client. A server plugin/mod that deliberately hides, fakes, or replaces health data requires a server-side integration/protocol of its own.

## Build

```bash
./gradlew build
```

The built jars are written to `Fabric/build/libs/`.
